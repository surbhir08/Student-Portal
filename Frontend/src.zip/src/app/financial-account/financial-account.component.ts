import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-financial-account',
  templateUrl: './financial-account.component.html',
  styleUrls: ['./financial-account.component.css']
})
export class FinancialAccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
