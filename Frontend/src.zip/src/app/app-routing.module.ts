import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { NewUserComponent } from './new-user/new-user.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { HomePageComponent } from './home-page/home-page.component';
import { StudentProfileComponent } from './student-profile/student-profile.component';
import { FinancialAccountComponent } from './financial-account/financial-account.component';

const routes: Routes = [
  { path: 'user-login', component: UserLoginComponent },
  { path: 'new-user', component: NewUserComponent },
  { path: 'home-page', component: HomePageComponent },
  { path: 'student-profile', component: StudentProfileComponent },
  { path: 'financial-account', component: FinancialAccountComponent },
  { path: '',   redirectTo: '/user-login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
