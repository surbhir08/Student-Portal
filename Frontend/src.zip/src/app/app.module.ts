import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NewUserComponent } from './new-user/new-user.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { HomePageComponent } from './home-page/home-page.component';
import { StudentProfileComponent } from './student-profile/student-profile.component';
import { FinancialAccountComponent } from './financial-account/financial-account.component';

@NgModule({
  declarations: [
    AppComponent,
    NewUserComponent,
    UserLoginComponent,
    HomePageComponent,
    StudentProfileComponent,
    FinancialAccountComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
